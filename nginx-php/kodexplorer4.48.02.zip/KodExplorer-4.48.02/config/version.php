<?php
define('KOD_VERSION','4.48');
define('KOD_VERSION_BUILD','02');//time(),20220516